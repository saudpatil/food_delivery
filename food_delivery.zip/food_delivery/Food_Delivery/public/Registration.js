// This is where you could add client-side validation or AJAX requests for registration/login

// Example JS for form submission (won't actually register or log in)
document.getElementById('registrationForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    const formObject = {};
    formData.forEach(function(value, key){
      formObject[key] = value;
    });
    console.log('Registration Data:', formObject);
    // Here you'd typically send this data to the server for registration
  });
  
  document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    const formObject = {};
    formData.forEach(function(value, key){
      formObject[key] = value;
    });
    console.log('Login Data:', formObject);
    // Here you'd typically send this data to the server for login verification
  });
  