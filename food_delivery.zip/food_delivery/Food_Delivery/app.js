const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();
const PORT = 4000;

// Body parser middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Serve static files (HTML, CSS)
app.use(express.static('public'));

// MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Nilesh@123',
  database: 'xenonstack', // Change to your database name
  port: 3307, // Default MySQL port is 3306
  authPlugins: {
    mysql_clear_password: () => () => Buffer.from('Nilesh@123')
  }
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to database:', err);
    return;
  }
  console.log('Connected to MySQL database');
});

// Endpoint for user registration
app.post('/register', (req, res) => {
  const { username, email, password } = req.body;

  const insertQuery = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
  connection.query(insertQuery, [username, email, password], (err, result) => {
    if (err) {
      console.error('Error registering user:', err);
      return res.status(500).send('Error registering user.');
    }
    console.log('Registered User:', { username, email });
    res.send('Registration successful!');
  });
});

// Endpoint for user login
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  console.log("Username " ,username);
  console.log("Password " ,password);

  const selectQuery = 'SELECT * FROM users WHERE username = ? AND password = ?';
  connection.query(selectQuery, [username, password], (err, results) => {
    console.log("In connection.queryr method");
    console.log("Username " ,username);
    console.log("Password " ,password);
   
    if (err) {
      console.error('Error logging in:', err);
      return res.status(500).send('Error logging in.');
    }
    if (results.length === 0) {
      return res.status(401).send('Invalid credentials.');
    }
    console.log('Login successful:', { username });
    res.send('Login successful!');
  });
});

// Server listening
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
